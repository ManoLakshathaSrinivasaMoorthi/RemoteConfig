package com.example.dynamicdata;

public class RemoteUtils {
    public static final String Title="Title";
    public static final String BodyContent="BodyParams";
    public static final String Version="Version";
    public static final String IsForce="";

    public static final String CONFIG_IS_PROMO_ON = "is_promotion_on";
    public static final String CONFIG_COLOR_PRY ="color_primary" ;
    public static final String CONFIG_BUTTON_COLOR ="button_color" ;
    public static final String CONFIG_TEXT_COLOR = "text_color";
    private static final String CONFIG_COLOR_count = "bodycolor";
}
