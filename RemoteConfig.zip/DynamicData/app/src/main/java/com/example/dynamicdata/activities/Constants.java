package com.example.dynamicdata.activities;

public interface Constants {
    interface  SharedPreference{
        String Vname="Vehicle_Name";
        String VCardigo="Vehicle_Codigo";
    }
}
